package spiderman;

import java.util.HashMap;

public class AjacencyValue {
    HashMap ajacency;
    


    
}
